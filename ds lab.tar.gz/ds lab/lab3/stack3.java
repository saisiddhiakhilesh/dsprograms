class Stack3
{
	char stack1[]=new char[20];
	int top=-1;
	boolean isEmpty()
	{
		if( top == -1 )
			return true;
		else
			return false;
	}
	boolean isFull()
	{
		if( top == 20 )
			return true;
		else
			return false;
	}
	void push(char ch)
	{
	if( isFull())
		{
			System.out.println("Overflow!");
		}
		else
		{
			top++;
			stack1[top] = ch;
			//displayElements();
		}
	}
	
	void pop()
	{
		if(isEmpty())
		{
			System.out.println("Underflow");
			
		}
		else
		{
			stack1[top] = 0;
			top--;
			//displayElements();
		}
	}
	int preference(char ch)
	{
		switch(ch)
		{
			case '-': return 1;
			case '+': return 1;
			case '/': return 2;
			case '*': return 2;
			case '^': return 3;
			
			// if you have more operators write those preferences
		}
		return 0;
	}
	boolean operator(char ch)
	{
		// To check whether an operator
		if(ch=='/'||ch=='*'||ch=='+'||ch=='-')
		return true;
		else
		return false;
	}
	boolean isAlpha(char ch)
	{
		// To check whether an alphabet
		//Include characters 0 t0 9
		if(ch>='a'&&ch<='z')
			return true;
		else if( ch >= '0' && ch <= '9' )
			return true;
		else
			return false;
	}
	void postfix(String str)
	{
		char output[]=new char[str.length()];
		char ch;
		int p=0,i;
		for(i=0;i<str.length();i++)
		{
			ch=str.charAt(i);
			if(ch=='(')
			{
				push(ch);
			}
			else if(isAlpha(ch))
			{
				output[p] = ch;
				p++;
			}
			else if(operator(ch))
			{
				while( isEmpty() == false && stack1[top] != '(' && (preference(stack1[top]) >= preference(ch)) ) 
				{
					output[p] = stack1[top];
					p++;
					pop();
				}
				push(ch);
			}
			else if( ch == ')' )
			{
				while( isEmpty() == false && stack1[top] != '(' )
				{
					output[p] = stack1[top];
					p++;
					pop();
				}
				pop();
			}
		//	while(top!=-1)
		//	{
				//
		//	}
			
		}
		while( isEmpty() == false )
		{
			output[p] = stack1[top];
			p++;
			pop();
		}
		for(int j=0;j<str.length();j++)
			{
				System.out.print(output[j]);
			}
	}
}
	
