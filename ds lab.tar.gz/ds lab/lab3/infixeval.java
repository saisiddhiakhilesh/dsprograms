import java.io.*;
class InfixEvaluator
{
	public static void main(String[] args) throws IOException
	{
		String s;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Stack4 b=new Stack4();
		System.out.println("Enter input string");
		s=br.readLine();
		System.out.println("Input String:"+s);
		System.out.println("Output String:");	
		b.evaluate(s);
	}
}
