import java.io.*;
class IntoPost
{
	public static void main(String[] args)throws Exception
	{
		String s;
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		Stack3 b=new Stack3();
		System.out.println("Enter input string");
		s=br.readLine();
		System.out.println("Input String:"+s);
		System.out.println("Output String:");	
		b.postfix(s);
	}
}
