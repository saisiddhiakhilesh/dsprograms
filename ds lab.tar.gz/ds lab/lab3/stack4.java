class Stack4
{
	int stack[]=new int[20];
	int top=-1;
	boolean isEmpty()
	{
		if( top == -1 )
			return true;
		else
			return false;
	}
	boolean isFull()
	{
		if( top == 20 )
			return true;
		else
			return false;
	}

	void push(int a)
	{
		if( isFull())
		{
			System.out.println("Overflow!");
		}
		else
		{
			top++;
			stack[top] = a;
			//displayElements();
		}
	}
	
	void pop()
	{
		if(isEmpty())
		{
			System.out.println("Underflow");
			
		}
		else
		{
			stack[top] = 0;
			top--;
			//displayElements();
		}
	}
	int preference(char ch)
	{
		switch(ch)
		{
			case '-': return 1;
			case '+': return 1;
			case '/': return 2;
			case '*': return 2;
			case '^': return 3;
			
			// if you have more operators write those preferences
		}
		return 0;
	}
	boolean operator(char ch)
	{
		// To check whether an operator
		if(ch=='/'||ch=='*'||ch=='+'||ch=='-')
		return true;
		else
		return false;
	}
	boolean isAlpha(char ch)
	{
		// To check whether an alphabet
		//Include characters 0 t0 9
		if(ch>='a'&&ch<='z')
			return true;
		else if( ch >= '0' && ch <= '9' )
			return true;
		else
			return false;
	}
	void evaluate(String s)
	{
		char ch; 
		String st;
		int op1, op2, res=0;
		int i, p = 0, a, b;
		for( i = 0; i < s.length(); i++)
		{
			ch = s.charAt(i);
			if(isAlpha(ch))
			{
				a = (int)ch - 48;
				push(a);
			}
			else if(operator(ch))
			{
				op2 = stack[top];
				pop();
				op1 = stack[top];
				pop();
				switch(ch)
				{
				case '+':	res = op1 + op2;
							break;
				case '-':	res = op1 - op2;
							break;		
				case '*':	res = op1 * op2;
							break;
				case '/':	res = op1 / op2;
							break;
				}
				push(res);
			}
		}
		res = stack[top];
		System.out.println("The result is: "+res);
	}

}
	
