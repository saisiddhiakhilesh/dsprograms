import java.util.Scanner;

class Driver4
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		CircularSingly list = new CircularSingly();
		System.out.println("Circular Singly Linked List Test");
		char ch;
		
		do
		{
			System.out.println("\nSingly Linked List Operations");
			System.out.println("1.insert at beginning");
			System.out.println("2.insert at end");
			System.out.println("3.delete at end");
			System.out.println("4.delete at beginning");
			System.out.println("5.delete at position");

			int choice = scan.nextInt();

			switch(choice)
			{
				case 1 :
				System.out.println("enter the data of the node");
				int data = scan.nextInt();
				list.insertAtHead(data);
				break;
				
				case 2 :
				System.out.println("enter the data of the node");
				int data1 = scan.nextInt();	
				list.insertAtEnd(data1);
				break;
				
				case 3 :
				list.deleteAtEnd();		
				break;

				case 4 :
				list.deleteAtHead();
				break;
				
				case 5 :
				System.out.println("enter the position of the node to be deleted");
				int key = scan.nextInt();
				list.deleteAtPos(key);
				break;
			}
			list.display();
			System.out.println("\nDo you want to continue (Type y or n) ");
			ch = scan.next().charAt(0);
		}while(ch == 'Y' || ch == 'y');
	}
}
