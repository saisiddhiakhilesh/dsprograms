import java.util.Scanner;

class CircularSingly
{
	public Node head;
	public int size;
	
	public CircularSingly()
	{
		head = null;
	}
	/* fn to insert at the end */
	public void insertAtEnd(int val)
	{
		Node newnode = new Node(val,null);
		Node temp = head;
		if(head == null)
		{
			head = newnode;
			head.next = head;
		}
		else
		{
			while(temp.next != head)
			{
				temp = temp.next;
			}
			temp.next = newnode;
			newnode.next = head;
		}
	}
	/* fn to insert at the Head */
	public void insertAtHead(int val)
	{
		Node newnode = new Node(val,null);
		Node temp = head;
		if(head == null)
		{
			head = newnode;
			head.next = head;
		}
		else
		{
			while(temp.next != head)
			{
				temp = temp.next;
			}
			temp.next = newnode;
			newnode.next = head;
			head = newnode;
		}
	}
	/* fn to delete node at the end */
	public void deleteAtEnd()
	{
		Node temp = head;
		if(head == null) 
			System.out.println("Can not be deleted");
		else if(head.next == head)
			head = null;
		else
		{
			while(temp.next.next != head)
			{
				temp = temp.next;
			}
			temp.next = head;
		}
	}
	/* fn to delete first node */
	public void deleteAtHead()
	{
		Node temp = head;
		if(head == null) 
			System.out.println("Can not be deleted");
		else if(head.next == head)
			head = null;
		else
		{
			while(temp.next != head)
			{
				temp = temp.next;
			}
			temp.next = head.next;
			head = head.next;
		}
	}
	/* fn to delete at position */
	public void deleteAtPos(int key)
	{
		if(head == null)
			System.out.println("can not be deleted");
		else if(head.next == head)
			head = null;
		else if(key == 1)
			deleteAtHead();
		else
		{
			Node temp = head;
			int i = 1;
			while(i != key)
			{
				temp = temp.next;
				i++;
			}
			temp.next = temp.next.next;
		}
	}
	/* fn to display elements */
	public void display()
	{
		System.out.println("Singly Linked List ");
		Node temp = head;
		if(temp == null)
		{
			System.out.print("Empty");
		}
		else
		{
			while(temp.next != head)
			{
				System.out.print(temp.data);
				temp = temp.next;
			}
			System.out.println(temp.data);
		}
	}
}

			
			
			
		
		
			
		


			
