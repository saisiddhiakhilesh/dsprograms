import java.util.Scanner;
public class Driver1
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		linkedList list = new linkedList();
		System.out.println("Singly Linked List Test");
		char ch;
		
		do
		{
			System.out.println("\nSingly Linked List Operations");
			System.out.println("1.insert at beginning");
			System.out.println("2.insert at end");
			System.out.println("3.insert at position");
			System.out.println("4.delete at position");
			System.out.println("5.check empty");
			System.out.println("6.get size");
			System.out.println("7. insert at beggining");
			
			int choice = scan.nextInt();
			switch(choice)
			{
				case 1 :
				System.out.println("enter the data of the node");
				int data = scan.nextInt();
				list.insertAtPos(data,1);
				break;

				case 2 :
				System.out.println("enter the data of the node");
				int data1 = scan.nextInt();
				list.insertAtEnd(data1);
				break;
	
				case 3 :
				System.out.println("enter the data of the node");
				int data2 = scan.nextInt();
				System.out.println("enter the position ");
				int pos1 = scan.nextInt();
				list.insertAtPos(data2,pos1);
				break;

				case 4 :
				System.out.println("enter the position");
				int pos = scan.nextInt();
				list.deleteAtPos(pos);
				break;
				
				case 5 :
				list.checkEmpty();
				break;
	
				case 6 :
				list.getSize();
				break;
				
				case 7 :
				int data3 = scan.nextInt();
				list.insertAtBeg(data3);
				break;
			}
			list.display();
			System.out.println("\nDo you want to continue (Type y or n) ");
			ch = scan.next().charAt(0);
		}while(ch == 'Y' || ch == 'y');
	}
}
		
			
				

