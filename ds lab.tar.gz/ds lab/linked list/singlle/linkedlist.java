import java.util.Scanner;

class linkedList
{
	public Node head;
	public int size;
	
	public linkedList()
	{
		head = null;
	}
	

	/* fn to insert at the end */
	public void insertAtEnd(int val)
	{
		Node newnode = new Node(val,null);
		Node temp;
		temp = head; 
		while(temp.next != null)
		{
			temp = temp.next;
		}
		temp.next = newnode;
	}
	//fn to remove at beg
	public void removeAtBeg()
	{
		Node temp;
		temp = head ;
		temp = temp.next ;
		head = null;
		head = temp.next ;
	}
	// fn to insert at beg 
	public int insertAtBeg (int val)
	{
		Node newnode = new Node ( val, null);
		Node temp;
		temp = head ;
		newnode.next = temp;
		temp = newnode ;
		head = newnode ;
		return val;
	}
	/* fn to insert at position */
	public void insertAtPos(int val,int pos)
	{
		Node newnode = new Node(val,null);
		Node temp;
		temp = head;
		int i = 1;
		if(temp == null)
		{
			temp = newnode;
			head = newnode;
		}
		else if(pos == 1)
		{

			newnode.next = temp;
			head = newnode;
		}
		else 
		{
			while(i != pos-1)
			{
				temp = temp.next;
				i++;
			}
			newnode.next = temp.next;
			temp.next = newnode;
		}
	}
	/* fn to delete at position */
	public void deleteAtPos(int pos)
	{
		Node temp;
		temp = head;
		int i = 1;
		while(i != pos-1)
		{
			temp = temp.next;
			i++;
		}
		temp.next = temp.next.next;
	}
	/* fn to display elements */
	public void display()
	{
		System.out.println("Singly Linked List ");
		Node temp = head;
		if(temp == null)
		{
			System.out.print("Empty");
		}
		else
		{
			while(temp.next != null)
			{
				System.out.print(temp.data);
				temp = temp.next;
			}
			System.out.println(temp.data);
		}
	}
	/* to check whether the list is Empty */
	public void checkEmpty()
	{
		if(head == null)
			System.out.println("Empty");
		else
			System.out.println("Not Empty");
	}
	/* to get the size */
	public int getSize()
	{
		int count=0;
		Node temp = head;
		if(temp == null)
		{
			count = 0;
		}
		else
		{
			while(temp.next != null)
			{	
				temp = temp.next;
				count++;
			}
			count++;
			System.out.println("count :"+count);
		}
		return count;
	}
		
}
 
	
	
		
		
