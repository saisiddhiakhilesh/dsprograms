import java.util.Scanner;

class DoubleNode
{
	public int data;
	public DoubleNode next;
	public DoubleNode prev;
	
	public DoubleNode()
	{
		data = 0;
		next = null;
		prev = null;
	}
	public DoubleNode(DoubleNode n,int x,DoubleNode p)
	{
		data = x;
		next = n;
		prev = p;
	}
	
}
