import java.util.Scanner;
public class DoubleList
{
	DoubleNode head;
	public DoubleList()
	{
		head = null;
	}
	/* fn to insert at head */
	public void insertAtHead(int x)
	{
		DoubleNode newnode  = new DoubleNode(null,x,null);
		if(head == null)
			head = newnode ;
		else
		{
			head.prev = newnode ;
			newnode.next = head;
			head = newnode;
		}
	}
	/*fn to insert at position */
	public void insertAtPos(int val,int key)
	{
		DoubleNode newnode1 = new DoubleNode(null,val,null);
		if(head == null)
			head = newnode1;
		else if((key == 1)&&(head.next == null))
		{
			newnode1.prev = head;
			head.next = newnode1;
		}
		else
		{
			DoubleNode temp = head;
			int i=1;
			while(i != key)
			{
				temp = temp.next;
				i++;
			}
			newnode1.prev = temp;
			newnode1.next = temp.next;
			temp.next.prev = newnode1;
			temp.next = newnode1;
		}
	}
	/*fn to delete at the end */
	public void deleteAtEnd()
	{
		if(head == null)
			System.out.println("can not be deleted");
		else if((head.next == null)&&(head.prev == null))
			head = null;
		else
		{
			DoubleNode temp = head;
			while(temp.next.next != null)
			{
				temp = temp.next;
			}
			temp.next = null;
		}
	}
	/* fn to delete the element at a position */
	public void deleteAtPos(int key)
	{
		if(head == null)
			System.out.println("can not be deleted");
		else if(key == 1)
		{
			head = head.next;
			head.prev = null;
		}
		else
		{
			DoubleNode temp = head;
			int i=1;
			while(i != key-1)
			{
				temp = temp.next;
				i++;
			}
			temp.next = temp.next.next;
			temp.next.prev = temp;
		}
	}		
	/* fn to display elements in forward */		
	public void display()
	{
		if(head == null)
			System.out.println("Empty List");
		else 
		{
			DoubleNode temp = head;
			while(temp.next != null)
			{
				System.out.print(temp.data);
				temp = temp.next;
			}
			System.out.print(temp.data);
		}
	}
	
	/* fn to display elements in backward */
	public void displayBackward()
	{
		if(head == null)
			System.out.println("Empty List");
		else 
		{
			DoubleNode temp1 = head;
			while(temp1.next != null)
			{
				temp1 = temp1.next;
			}
			DoubleNode temp2 = temp1;
			while(temp2.prev != null)
			{
				System.out.print(temp2.data);
				temp2 = temp2.prev;
			}
			System.out.print(temp2.data);
		}
	}
	
}
