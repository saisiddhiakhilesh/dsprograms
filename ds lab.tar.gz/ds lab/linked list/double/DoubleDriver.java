import java.util.Scanner;
public class DoubleDriver
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		DoubleList list = new DoubleList();
		char ch;
		do
		{
			System.out.println("\nDoubly Linked List Operations");
			System.out.println("1.insert at beginning");
			System.out.println("2.insert at position");
			System.out.println("3.delete at end");
			System.out.println("4.delete at position");
			System.out.println("5.display in forward");
			System.out.println("6.display in backward");
			int choice = scan.nextInt();
			switch(choice)
			{
				case 1 :
				System.out.println("enter the data of the node");
				int data = scan.nextInt();
				list.insertAtHead(data);
				list.display();
				break;
			
				case 2 :
				System.out.println("enter the data and position of the node");
				int data1 = scan.nextInt();
				int pos = scan.nextInt();
				list.insertAtPos(data1,pos);
				list.display();
				break;
		
				case 3 :
				list.deleteAtEnd();
				list.display();
				break;

				case 4 :
				System.out.println("enter the position of the node");
				int pos2 = scan.nextInt();
				list.deleteAtPos(pos2);
				list.display();
				break;
				
				case 5 :
				System.out.println("display of elements in forward");
				list.display();
				break;
				
				case 6:
				System.out.println("display of elements in backward");
				list.displayBackward();
				break;
				
			}
			System.out.println("\nDo you want to continue (Type y or n) ");
			ch = scan.next().charAt(0);
		}while(ch == 'Y' || ch == 'y');
	}	
}
