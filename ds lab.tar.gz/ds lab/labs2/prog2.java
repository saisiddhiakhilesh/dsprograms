public class Prog2
{
	public static void main(String[] args)
	{
		boolean c = true;
		//char ex[] ={'{', '(', ')', '{', '[', '(', ')', ']', '}','}'};
		//char ex[] = {'[','(',']',')'};
		char ex[] = {')','('};
		//char ex[] ={'{', '(', ')', '(', ')', '(', ')', '[', '{', '}', ']', '}' };
		Stack2 l = new Stack2();
		for( int i = 0; i < ex.length; i++)
		{
			if(ex[i] == '{' || ex[i] == '(' || ex[i] == '[')
			{
				l.push(ex[i]);
			}
			else 
			{
				if(l.isEmpty())
				{
					c = false;
					break;
				}
				else
				{
					if(l.compare(ex[i]))
						l.pop();
					else
						break;
				}
			}
				
		}
		if( c == true )
		{
			if(l.isEmpty())
				System.out.println("The expression is balanced!");
			else
				System.out.println("The expression is not balanced!");
		}
		else
			System.out.println("The expression is not balanced!");
	}

}
