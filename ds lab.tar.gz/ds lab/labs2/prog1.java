public class Prog1
{
	public static void main(String[] args)
	{
		Stack s = new Stack();
		s.push(5);
		s.push(3);
		s.push(4);
		s.push(12);
		s.pop();
		int n = s.getSize();
		System.out.println("The size of the stack is: "+n);
		int m = s.getTop();
		System.out.println("The top element is: "+m);
	}
}
