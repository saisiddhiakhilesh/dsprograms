import java.util.*;
public class StackDemo
{
	public static void main(String args[]) 
	{
		Stack st = new Stack();
		st.push(5);
		st.push(15);
		System.out.println("stack: " + st);
//	System.out.println("peek: "+st.peek());
		st.pop();
		System.out.println("stack: " + st);
//		System.out.println("Is stack empty: "+st.empty());
		try {
		}
		catch (EmptyStackException e) {
			System.out.println("emptystack");
		}
	}
}
