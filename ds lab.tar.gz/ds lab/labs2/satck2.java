public class Stack2
{
	private static int n_size = 10;
	char A[] = new char[n_size];
	int top = -1;
	
	public void push(char x)
	{
		if( isFull())
		{
			System.out.println("Overflow!");
		}
		else
		{
			top++;
			A[top] = x;
			//displayElements();
		}
	}
	public void pop()
	{
		if(isEmpty())
		{
			System.out.println("Underflow");
		}
		else
		{
			A[top] = 0;
			top--;
			//displayElements();
		}
	}
	public void displayElements()
	{
		for(int i = 0; i <= top; i++)
		{
			System.out.println(A[i]);
		}
	}
	public int getSize()
	{
		return top+1;
	}
	public int getTop()
	{
		return A[top];
	}
	public boolean isEmpty()
	{
		if( top == -1 )
			return true;
		else
			return false;
	}
	public boolean isFull()
	{
		if( top == n_size )
			return true;
		else
			return false;
	}
	public boolean compare(char e)
	{
		if(A[top] == '(')
		{
			if(e == ')')
				return true;
			else 
				return false;
		}
		else if(A[top] == '[')
		{
			if(e == ']')
				return true;
			else 
				return false;
		}
		else if(A[top] == '{')
		{
			if(e == '}')
				return true;
			else 
				return false;
		}
		else
			return false;
	}
}
