public class Stack
{
	private static int n_size = 10;
	int A[] = new int[n_size];
	int top = -1;
	
	public void push(int x)
	{
		if( isFull())
		{
			System.out.println("Overflow!");
		}
		else
		{
			top++;
			A[top] = x;
			displayElements();
		}
	}
	public void pop()
	{
		if(isEmpty())
		{
			System.out.println("Underflow");
		}
		else
		{
			A[top] = 0;
			top--;
			displayElements();
		}
	}
	public void displayElements()
	{
		for(int i = 0; i <= top; i++)
		{
			System.out.println(A[i]);
		}
	}
	public int getSize()
	{
		return top+1;
	}
	public int getTop()
	{
		return A[top];
	}
	public boolean isEmpty()
	{
		if( top == -1 )
			return true;
		else
			return false;
	}
	public boolean isFull()
	{
		if( top == n_size )
			return true;
		else
			return false;
	}
}
