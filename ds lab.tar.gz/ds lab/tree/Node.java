import java.util.*;
import java.io.*;
public class Node
{
	Node left;
	int data;
	Node right;
	public Node()
	{
		left = null;
		data = 0;
		right = null;
	}
	
	public Node(int d)
	{
		left = null;
		data = d;
		right = null;
	}
}
