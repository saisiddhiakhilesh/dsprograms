import java.util.*;
public class BinaryTree {
	NODE A=null;
	Queue<NODE> que = new LinkedList<NODE>();
	NODE BFSNode(NODE nod) {
		que.poll();
		if(nod.left==null)
			return nod;
		else
			que.add(nod.left);
		if(nod.right==null)
			return nod;
		else
			que.add(nod.right);
		return BFSNode(que.peek());
	}
	NODE findIncompleteNode() {
		que.clear();
		que.add(A);
		NODE temp = BFSNode(que.peek());
		return temp;
	}
	NODE BFSParent(NODE nod,NODE temp) {
		que.poll();
		if(nod.left==null)
			return temp;
		else
			que.add(nod.left);
		temp=nod;
		if(nod.right==null)
			return temp;
		else
			que.add(nod.right);
		return BFSParent(que.peek(),temp);
	}
	NODE findLastParent() {
		que.clear();
		que.add(A);
		NODE temp=A;
		temp = BFSParent(que.peek(),temp);
		return temp;
	}
	NODE BFSFind(NODE nod,int x) {
		que.poll();
		if(nod.value==x)
			return nod;
		else
		{
			if(nod.left!=null)
				que.add(nod.left);
			if(nod.right!=null)
				que.add(nod.right);
		}
		if(!que.isEmpty()) {
			return BFSFind(que.peek(),x);
		}
		else {
			return null;
		}
	}
	void insert(int x) {
		NODE y = new NODE(x);
		if(A==null)
			A=y;
		else
		{	
			NODE temp = findIncompleteNode();
			if(temp.left==null)
				temp.left=y;
			else
				temp.right=y;
		}
		display();
	}
	NODE find(int x) {
		que.clear();
		que.add(A);
		NODE temp=null;
		temp=BFSFind(que.peek(),x);
		return temp;
	}
	void Delete(int x) {
		NODE temp = findLastParent();
		NODE temp1 = find(x);
		if(temp1==null) {
			System.out.println("No such element");	
		}
		else {
			if(temp.right!=null) {
				temp1.value=temp.right.value;
				temp.right=null;
			}
			else if(temp.left!=null) {
				temp1.value=temp.left.value;
				temp.left=null;
			}
			else {
				A=null;
			}
			display();
		}
	}
	void doPreOrder(NODE nod) {
		if(nod==null)
			return;
		System.out.print(nod.value+" ");
		doPreOrder(nod.left);
		doPreOrder(nod.right);
	}
	void PerOrder() {
		doPreOrder(A);
		System.out.println();
	}
	void doPostOrder(NODE nod) {
		if(nod==null)
			return;
		doPostOrder(nod.left);
		doPostOrder(nod.right);
		System.out.print(nod.value+" ");
	}
	void PostOrder() {
		doPostOrder(A);
		System.out.println();
	}
	void doInOrder(NODE nod) {
		if(nod==null)
			return;
		doInOrder(nod.left);
		System.out.print(nod.value+" ");
		doInOrder(nod.right);		
	}
	void InOrder() {
		doInOrder(A);
		System.out.println();
	}
	void Print(NODE nod) {
		if(nod==null)
			return;
		que.poll();
		System.out.print(nod.value + " ");
		if(nod.left!=null)
			que.add(nod.left);
		if(nod.right!=null)
			que.add(nod.right);
		if(!que.isEmpty()) {
			Print(que.peek());
		}
	}
	void display() {
		que.clear();
		que.add(A);
		Print(que.peek());
		System.out.println();
	}
}
