import java.util.*;
import java.io.*;

public class Driver
{
	public static void main(String [] args)
	{
		BST b = new BST();
		Scanner s = new Scanner(System.in);
		System.out.println("BST operations");
		char ch;
		do
		{
			System.out.println("1.Insertion");
			System.out.println("2.Inorder");
			System.out.println("3.Preorder");
			System.out.println("4.Postorder");
			System.out.println("5.Search");
			System.out.println("6.Deletion");
			
			System.out.println("Enter your choice: ");
			int n = s.nextInt();
			switch(n)
			{
				case 1 : 
				System.out.println("Enter the no 0f elements to be inserted");
				int x = s.nextInt();
				for(int i=0 ; i < x ; i++)
				{
					System.out.println("enter the data of the node :");
					int y = s.nextInt();
					b.root = b.Insertion(b.root,y);
				}
				break;

				case 2 :
				System.out.println("After Inorder Traversal");
				b.Inorder(b.root);
				break;

				case 3 :
				System.out.println("After Preorder Traversal");
				b.Preorder(b.root);
				break;

				case 4 :
				System.out.println("After Postorder Traversal");
				b.Postorder(b.root);
				break;

				case 5 :
				System.out.println("Enter the data to be searched");
				int d = s.nextInt();
				b.Search(d,b.root);
				break;

				case 6 : 
				System.out.println("enter the data of the node to be deleted:");
				int d2 = s.nextInt();
				b.root = b.Deletion(b.root,d2);
				break;

				default:
				System.out.println("your choice is beyond limit");
			}
			System.out.println("\nDo you want to continue (Type y or n) ");
				ch = s.next().charAt(0);
		}while(ch == 'Y' || ch == 'y');
	}
}
