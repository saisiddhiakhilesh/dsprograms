import java.util.*;
import java.io.*;
public class BST
{
	Node root = null;

	public  BST()
	{
		root = null;
	}

	public Node Insertion(Node root1,int x)
	{
		if(root1 == null)
			root1 = new Node(x);
		else if(x<root1.data)
		{
			root1.left = Insertion(root1.left,x);
		}
		else
		{
			root1.right = Insertion(root1.right,x);
		}
		return root1;
	}
	public void Visit(Node n)
	{
		System.out.print(n.data + " " );
	}
	public void Inorder(Node root2)
	{
		if(root2 == null)
			return;
		else
		{
			Inorder(root2.left);
			Visit(root2);
			Inorder(root2.right);
		}
	}
	public void Preorder(Node root3)
	{
		if(root3 == null)
			return;
		else
		{	
			Visit(root3);
			Preorder(root3.left);
			Preorder(root3.right);
		}
	}
	public void Postorder(Node root4)
	{
		if(root4 == null)
			return;
		else
		{
			Postorder(root4.left);
			Postorder(root4.right);
			Visit(root4);
		}
	}
	public void Search(int data1 , Node root5)
	{
		if(data1 == root5.data)
		{
			System.out.println("\nData found");
			return ;
		}
		else if(data1 < root5.data)
		{
			if(root5.left == null)
				System.out.println("\nData Not found");
			else
				Search(data1,root5.left);
		}
		else
		{
			if(root5.right == null)
				System.out.println("\nData Not found");
			else
			Search(data1,root5.right);
		}
	}
	public Node Deletion(Node root6, int data2)
	{
		if (root6 == null)  
			return root6;
        	else if (data2 < root6.data)
            		root.left = Deletion(root6.left, data2);
        	else if (data2 > root6.data)
            		root6.right = Deletion(root6.right, data2);
       		else
        	{
           	 if (root6.left == null)
                	return root6.right;
           	 else if (root6.right == null)
               	 	return root6.left;
            	root6.data = Successor(root6.right);
            	root6.right = Deletion(root6.right, root6.data);
        	}
 
        return root6; 
	}
	
	public int Predecessor(Node root7)
	{
		while(root7.right != null)
			root7 = root7.right;
		return root7.data;
	}
	
	public int Successor(Node root8)
	{
		while(root8.left != null)
			root8 = root8.left;
		return root8.data;
	}
			
}
